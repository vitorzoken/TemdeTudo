package com.example.temdetudo;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class CadastroActivity extends AppCompatActivity {

    private TextInputEditText nomeCompletoEditText;
    private TextInputEditText emailEditText;
    private TextInputEditText telefoneEditText;
    private TextInputEditText dataNascimentoEditText;
    private RadioGroup generoRadioGroup;
    private CheckBox termosCheckBox;
    private Calendar dataNascimentoCalendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        // Inicializa os componentes
        nomeCompletoEditText = findViewById(R.id.nomeCompletoEditText);
        emailEditText = findViewById(R.id.emailEditText);
        telefoneEditText = findViewById(R.id.telefoneEditText);
        dataNascimentoEditText = findViewById(R.id.dataNascimentoEditText);
        generoRadioGroup = findViewById(R.id.generoRadioGroup);
        termosCheckBox = findViewById(R.id.termosCheckBox);
        Button confirmarButton = findViewById(R.id.confirmarButton);

        // Configura o date picker para a data de nascimento
        dataNascimentoCalendar = Calendar.getInstance();
        dataNascimentoEditText.setOnClickListener(v -> mostrarDatePicker());

        confirmarButton.setOnClickListener(v -> validarCadastro());
    }

    private void mostrarDatePicker() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    dataNascimentoCalendar.set(Calendar.YEAR, year);
                    dataNascimentoCalendar.set(Calendar.MONTH, month);
                    dataNascimentoCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    atualizarDataNascimento();
                },
                dataNascimentoCalendar.get(Calendar.YEAR),
                dataNascimentoCalendar.get(Calendar.MONTH),
                dataNascimentoCalendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        datePickerDialog.show();
    }

    private void atualizarDataNascimento() {
        String formatoData = "dd/MM/yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(formatoData, Locale.getDefault());
        dataNascimentoEditText.setText(sdf.format(dataNascimentoCalendar.getTime()));
    }

    private void validarCadastro() {
        String nomeCompleto = nomeCompletoEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        String telefone = telefoneEditText.getText().toString().trim();
        String dataNascimento = dataNascimentoEditText.getText().toString().trim();
        int generoId = generoRadioGroup.getCheckedRadioButtonId();
        boolean aceitouTermos = termosCheckBox.isChecked();

        if (nomeCompleto.isEmpty()) {
            nomeCompletoEditText.setError("Por favor, insira seu nome completo");
            return;
        }

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailEditText.setError("Por favor, insira um e-mail válido");
            return;
        }

        if (telefone.isEmpty() || telefone.length() < 10) {
            telefoneEditText.setError("Por favor, insira um telefone válido");
            return;
        }

        if (dataNascimento.isEmpty()) {
            dataNascimentoEditText.setError("Por favor, selecione sua data de nascimento");
            return;
        }

        if (generoId == -1) {
            Toast.makeText(this, "Por favor, selecione seu gênero", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!aceitouTermos) {
            Toast.makeText(this, "Você deve aceitar os termos para continuar", Toast.LENGTH_SHORT).show();
            return;
        }

        // Obter o gênero selecionado
        RadioButton generoRadioButton = findViewById(generoId);
        String genero = generoRadioButton.getText().toString();

        // Enviar dados para a tela de confirmação
        Intent intent = new Intent(CadastroActivity.this, ConfirmacaoActivity.class);
        intent.putExtra("NOME_COMPLETO", nomeCompleto);
        intent.putExtra("EMAIL", email);
        intent.putExtra("TELEFONE", telefone);
        intent.putExtra("DATA_NASCIMENTO", dataNascimento);
        intent.putExtra("GENERO", genero);
        startActivity(intent);
    }
}